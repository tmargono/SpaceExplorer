#include "text.h"

using namespace std;

void texts::clearstage1() {
	//pause game
	//display picture (optional)
	//create textbox on bottom of the screen
	//cout the descriptions
}
void texts::clearstage2() {
	//pause game
	//display picture (optional)
	//create textbox on bottom of the screen
	//cout the descriptions
}
void texts::clearstage3() {
	//pause game
	//display picture (optional)
	//create textbox on bottom of the screen
	//cout the descriptions
}
void texts::clearstage4() {
	//pause game
	//display picture (optional)
	//create textbox on bottom of the screen
	//cout the descriptions
}