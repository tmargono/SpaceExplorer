#ifndef monster_h
#define monster_h

class texts {
public:
	void clearstage1();
	void clearstage2();
	void clearstage3();
	void clearstage4();
};

#endif